let ageCheck = confirm('Вам есть 15 лет?');


if (ageCheck) {
    alert('Доступ разрешен');
} else{
    alert('Доступ не разрешен');
}
