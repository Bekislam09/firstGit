let count = prompt();

for (let i = 0; i < count; i++) {
    let color;
        color = 'red'
    document.write(`<div style='background-color: ${color}; width:200px; height:200px; display:block; margin:5px'></div>`)
}
