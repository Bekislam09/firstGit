// function crishtiano(ronaldo){
//    return ronaldo.map(num => num * 2)
// }
// console.log(crishtiano([1, 2, 3]));
// console.log(crishtiano([4, 1, 1, 1, 4]));
// console.log(crishtiano([2, 2, 2, 2, 2, 2]));

// function otr(pol){
//     return pol.map(num => -num)
// }
// console.log(otr([1, 2, 3, 4, 5]));
// console.log(otr([1, -2, 3, -4, 5]));
// console.log(otr([]));
// console.log(otr([0]));

// function bek(abc){
//     return abc.map(element => typeof element === 'string' ? null : element )
// }
// console.log(bek([4, 6, 'Ivan', 5, 'Denis ']));

// function name(names){
//     return names.filter(element => element.length <= 5)
// }

// console.log(name(['Евдоким','Ivan', 'Игнат', 'Denis']));


// function num(number){
//     return number.map(num => num ** 3)
// }

// console.log(num([7, 8, 2]));


// function messi(pepsi){
//     return pepsi.map(e => e.length );
// }

// console.log(messi(['Термос', 'Ураган', 'Земля', 'Комбо', 'Корень']));


function crish(ron) {
    return ron.map(number => `<p>Цифры: ${number}</p>`)
}

document.write(crish([1, 2, 3, 4, 5]));

// const friends = [
//     { name: 'alex', pizzas: ['cheese', 'pepperoni'] },
//     { name: 'mike', pizzas: ['salami', 'margarita'] },
//     { name: 'stas', pizzas: ['meat'] },
//     { name: 'anna', pizzas: ['fish'] }
// ];
  
// const pizzasArray = friends.map(friend => friend.pizzas);
// console.log(pizzasArray);